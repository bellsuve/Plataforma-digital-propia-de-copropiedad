// Simple single-file demo app. Persistencia con localStorage.
const STORAGE_KEY='copropiedad_demo_v1';
let state = {
  reservations:[],
  units:[],
  reports:[],
  votes:[],
  activity:[],
  user: 'Invitado'
};

function load(){
  try{
    const raw = localStorage.getItem(STORAGE_KEY);
    if(raw){ Object.assign(state, JSON.parse(raw)); }
  }catch(e){ console.error(e); }
}
function save(){ localStorage.setItem(STORAGE_KEY, JSON.stringify(state)); renderAll(); }

// helpers
function addActivity(text){ state.activity.unshift({t: new Date().toISOString(), text}); if(state.activity.length>50) state.activity.pop(); save(); }
function formatDateISO(d){ const dt=new Date(d); if(isNaN(dt)) return d; return dt.toISOString().slice(0,10); }

// Navigation
document.querySelectorAll('#menu li').forEach(li=>{
  li.addEventListener('click', ()=>{ document.querySelectorAll('#menu li').forEach(x=>x.classList.remove('active')); li.classList.add('active'); document.querySelectorAll('.view').forEach(v=>v.style.display='none'); document.getElementById(li.dataset.view).style.display='block'; });
});

// Calendar rendering (simple month grid)
function renderCalendar(){
  const root = document.getElementById('calendarRoot'); root.innerHTML='';
  const now = new Date(); const year=now.getFullYear(); const month=now.getMonth();
  const first = new Date(year,month,1); const startDay = first.getDay();
  const daysInMonth = new Date(year,month+1,0).getDate();
  // add blanks for alignment (assuming Sun=0)
  for(let i=0;i<startDay;i++){ const blank=document.createElement('div'); blank.className='day'; blank.innerHTML=''; root.appendChild(blank); }
  for(let d=1; d<=daysInMonth; d++){
    const dateStr = new Date(year,month,d).toISOString().slice(0,10);
    const el=document.createElement('div'); el.className='day';
    el.innerHTML = `<div class="date">${d} ${new Intl.DateTimeFormat('es-ES',{month:'short'}).format(new Date(year,month,d))}</div>`;
    const bookings = state.reservations.filter(r=> !(r.end < dateStr || r.start > dateStr));
    bookings.forEach(b=>{ const bdiv=document.createElement('div'); bdiv.className='booking'; bdiv.textContent = `${b.name} • ${b.unit}`; el.appendChild(bdiv); });
    root.appendChild(el);
  }
}

// Reservations
document.getElementById('createRes').addEventListener('click', ()=>{
  const name = document.getElementById('resName').value.trim();
  const unit = document.getElementById('resUnit').value.trim() || 'Sin fracción';
  const start = document.getElementById('resStart').value;
  const end = document.getElementById('resEnd').value;
  if(!name || !start || !end){ alert('Completa nombre y fechas'); return; }
  if(end < start){ alert('Fecha fin no puede ser anterior a inicio'); return; }
  const id = 'res_'+Date.now();
  state.reservations.push({id,name,unit,start,end});
  addActivity(`Reserva: ${name} (${unit}) ${start} → ${end}`);
  save(); clearResForm();
});
function clearResForm(){ document.getElementById('resName').value=''; document.getElementById('resUnit').value=''; document.getElementById('resStart').value=''; document.getElementById('resEnd').value=''; }
document.getElementById('clearRes').addEventListener('click', clearResForm);

function renderReservations(){
  const root = document.getElementById('reservationsList'); root.innerHTML='';
  if(state.reservations.length===0) root.innerHTML='<div class="small muted">No hay reservas</div>';
  state.reservations.slice().reverse().forEach(r=>{
    const tr=document.createElement('div'); tr.style.padding='8px'; tr.style.borderBottom='1px solid #f1f5f9';
    tr.innerHTML = `<strong>${r.name}</strong> <div class="small">${r.unit} • ${formatDateISO(r.start)} → ${formatDateISO(r.end)}</div>`;
    const del = document.createElement('button'); del.textContent='Eliminar'; del.style.marginTop='6px'; del.addEventListener('click', ()=>{ if(confirm('Eliminar reserva?')){ state.reservations = state.reservations.filter(x=>x.id!==r.id); addActivity('Reserva eliminada'); save(); } });
    tr.appendChild(del); root.appendChild(tr);
  });
}

// Units (fractions)
document.getElementById('addUnit').addEventListener('click', ()=>{
  const name = document.getElementById('unitName').value.trim();
  const price = Number(document.getElementById('unitPrice').value) || 0;
  const weeks = Number(document.getElementById('unitWeeks').value) || 52;
  if(!name){ alert('Nombre de fracción requerido'); return; }
  const id = 'unit_'+Date.now();
  state.units.push({id,name,price,weeks});
  addActivity(`Fracción agregada: ${name}`); save(); document.getElementById('unitName').value='';
});

function renderUnits(){
  const root = document.getElementById('unitsList'); root.innerHTML='';
  if(state.units.length===0) root.innerHTML='<div class="small muted">No hay fracciones</div>';
  state.units.slice().reverse().forEach(u=>{
    const el=document.createElement('div'); el.style.padding='8px'; el.style.borderBottom='1px solid #f1f5f9';
    el.innerHTML = `<strong>${u.name}</strong> <div class="small">Precio: $${u.price.toLocaleString('es-MX')} • semanas/año: ${u.weeks}</div>`;
    const del = document.createElement('button'); del.textContent='Eliminar'; del.style.marginTop='6px'; del.addEventListener('click', ()=>{ if(confirm('Eliminar fracción?')){ state.units = state.units.filter(x=>x.id!==u.id); addActivity('Fracción eliminada'); save(); } });
    el.appendChild(del); root.appendChild(el);
  });
}

// Maintenance
document.getElementById('createRep').addEventListener('click', ()=>{
  const name = document.getElementById('repName').value.trim();
  const place = document.getElementById('repPlace').value.trim();
  const desc = document.getElementById('repDesc').value.trim();
  if(!name || !desc){ alert('Completa nombre y descripción'); return; }
  const id='rep_'+Date.now();
  state.reports.push({id,name,place,desc,status:'abierto',created:new Date().toISOString()});
  addActivity(`Reporte creado: ${place} (${name})`); save(); document.getElementById('repName').value=''; document.getElementById('repPlace').value=''; document.getElementById('repDesc').value='';
});
function renderReports(){
  const root = document.getElementById('reportsList'); root.innerHTML='';
  if(state.reports.length===0) root.innerHTML='<div class="small muted">No hay reportes</div>';
  state.reports.slice().reverse().forEach(r=>{
    const el=document.createElement('div'); el.style.padding='8px'; el.style.borderBottom='1px solid #f1f5f9';
    el.innerHTML = `<strong>${r.place || 'Sin lugar'}</strong> <div class="small">${r.name} • ${new Date(r.created).toLocaleString()}</div><div style="margin-top:6px">${r.desc}</div>`;
    const done = document.createElement('button'); done.textContent='Marcar como resuelto'; done.style.marginTop='6px'; done.addEventListener('click', ()=>{ r.status='resuelto'; addActivity('Reporte resuelto'); save(); });
    const del = document.createElement('button'); del.textContent='Eliminar'; del.style.margin='6px'; del.addEventListener('click', ()=>{ if(confirm('Eliminar reporte?')){ state.reports = state.reports.filter(x=>x.id!==r.id); addActivity('Reporte eliminado'); save(); } });
    el.appendChild(done); el.appendChild(del); root.appendChild(el);
  });
}

// Voting
document.getElementById('createVote').addEventListener('click', ()=>{
  const title = document.getElementById('voteTitle').value.trim();
  const opts = document.getElementById('voteOptions').value.trim();
  if(!title || !opts){ alert('Completa título y opciones'); return; }
  const options = opts.split(',').map(s=>s.trim()).filter(Boolean).map((o,i)=>({id:`opt_${i}_${Date.now()}`,label:o,count:0}));
  const id='vote_'+Date.now();
  state.votes.push({id,title,options,open:true,created:new Date().toISOString()});
  addActivity(`Votación creada: ${title}`); save(); document.getElementById('voteTitle').value=''; document.getElementById('voteOptions').value='';
});

function renderVotes(){
  const root = document.getElementById('votesList'); root.innerHTML='';
  if(state.votes.length===0) root.innerHTML='<div class="small muted">No hay votaciones</div>';
  state.votes.slice().reverse().forEach(v=>{
    const el=document.createElement('div'); el.style.padding='8px'; el.style.borderBottom='1px solid #f1f5f9';
    el.innerHTML = `<strong>${v.title}</strong> <div class="small">Creada: ${new Date(v.created).toLocaleString()} • ${v.open?'<span class=ok>Abierta</span>':'<span class=danger>Cerrada</span>'}</div>`;
    const optsRoot=document.createElement('div'); optsRoot.style.marginTop='8px';
    v.options.forEach(opt=>{
      const optEl=document.createElement('div'); optEl.className='vote-option';
      optEl.innerHTML = `<div>${opt.label} <span class="small muted">(${opt.count})</span></div>`;
      const btn = document.createElement('button'); btn.textContent='Votar'; btn.disabled=!v.open; btn.addEventListener('click', ()=>{ opt.count++; addActivity(`Votó ${opt.label} en ${v.title}`); save(); });
      optEl.appendChild(btn); optsRoot.appendChild(optEl);
    });
    const close = document.createElement('button'); close.textContent = v.open? 'Cerrar votación':'Reabrir'; close.style.marginTop='6px'; close.addEventListener('click', ()=>{ v.open = !v.open; addActivity((v.open? 'Votación reabierta: ':'Votación cerrada: ')+v.title); save(); });
    const del = document.createElement('button'); del.textContent='Eliminar'; del.style.margin='6px'; del.addEventListener('click', ()=>{ if(confirm('Eliminar votación?')){ state.votes = state.votes.filter(x=>x.id!==v.id); addActivity('Votación eliminada'); save(); } });
    el.appendChild(optsRoot); el.appendChild(close); el.appendChild(del); root.appendChild(el);
  });
}

// Settings
document.getElementById('settingUser').addEventListener('input', (e)=>{ state.user = e.target.value || 'Invitado'; document.getElementById('userTag').textContent = 'Usuario: '+state.user; save(); });

// Export
document.getElementById('exportBtn').addEventListener('click', ()=>{
  const data = JSON.stringify(state, null, 2);
  const blob = new Blob([data], {type:'application/json'});
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a'); a.href=url; a.download='copropiedad_export.json'; document.body.appendChild(a); a.click(); a.remove(); URL.revokeObjectURL(url);
});

// Clear storage
document.getElementById('clearAll').addEventListener('click', ()=>{ if(confirm('Borrar todos los datos locales?')){ localStorage.removeItem(STORAGE_KEY); state={reservations:[],units:[],reports:[],votes:[],activity:[],user:'Invitado'}; load(); save(); } });

// Activity
function renderActivity(){ const root=document.getElementById('activityList'); root.innerHTML=''; state.activity.slice(0,20).forEach(a=>{ const d=document.createElement('div'); d.style.padding='6px 0'; d.innerHTML = `<div class="small muted">${new Date(a.t).toLocaleString()}</div><div>${a.text}</div>`; root.appendChild(d); }); }

// KPIs + general render
function renderAll(){ document.getElementById('kpiReservations').textContent = state.reservations.length;
  document.getElementById('kpiMaintenance').textContent = state.reports.length;
  document.getElementById('kpiVotes').textContent = state.votes.filter(v=>v.open).length;
  document.getElementById('userTag').textContent = 'Usuario: '+(state.user||'Invitado');
  renderCalendar(); renderReservations(); renderUnits(); renderReports(); renderVotes(); renderActivity(); }

// Initial load
load(); renderAll();

// For demo: prefill example data if empty
if(state.reservations.length===0 && state.activity.length===0){ state.reservations.push({id:'res_demo1',name:'María',unit:'A',start:formatDateISO(new Date()),end:formatDateISO(new Date())}); state.units.push({id:'unit_demo',name:'A',price:850000,weeks:52}); state.reports.push({id:'rep_demo',name:'Luis',place:'Jardín',desc:'Luz exterior fundida',status:'abierto',created:new Date().toISOString()}); state.votes.push({id:'vote_demo',title:'Instalar WiFi común',options:[{id:'o1',label:'Sí',count:3},{id:'o2',label:'No',count:1}],open:true,created:new Date().toISOString()}); addActivity('Demo: datos iniciales creados'); save(); }

// Accessibility: keyboard quick create (Alt+R -> focus reservation start)
document.addEventListener('keydown', (e)=>{ if(e.altKey && e.key.toLowerCase()==='r'){ document.getElementById('resName').focus(); } });
